// Author: Bella Singh
// ISU Netid: bellas23
// Date: April 18th, 2024

fetch("http://localhost:8081/listRobots")
    .then(response => response.json())
    .then(robots => loadRobotList(robots));

//load one robot
function loadOneRobot(robot) {
    var cardContainer = document.getElementById("col");
    let card = document.createElement("div");
    card.classList.add("col");
    card.innerHTML = `
            <div class="card shadow-sm">
                <img src="${robot.imageUrl}" class="card-img-top" alt="...">
                <div class="card-body">
                    <p class="card-text"> <strong>${robot.name}</strong>, ${robot.description}, $${robot.price}</p>
                </div>
            </div>
        `;
    cardContainer.appendChild(card);
}

//load robot list
function loadRobotList(robots) {
    var cardContainer = document.getElementById("col");
    cardContainer.innerHTML = "";
    robots.forEach((robot, index) => {
        loadOneRobot(robot);
    });
}

//find robot
function findRobot() {
    var id = document.getElementById('robotId').value;
    fetch("http://localhost:8081/" + id)
        .then(response => response.json())
        .then(robot => {
            loadOneRobot(robot);
        })
        .catch(error => {
            console.error('Error fetching robot:', error);
        });
}

//add specifically robot 4
async function addRobot(robot) {
    const form = {
        id: 4,
        name: "Robot Bella",
        price: 90.4,
        description: "This is a description of Robot Bella",
        imageUrl: "https://robohash.org/Bella"
    }
    const response = await fetch("http://localhost:8081/addRobot", {
        method: 'POST',
        headers: { "Content-type": "application/json" },
        body: JSON.stringify(form)
    });
    const data = await response.json();
    alert("Robot added successfully! Click 'All Robots' to view updated list");
}

//delete robot
function deleteRobot() {
    let id = document.getElementById("deleteRobotById").value;
    console.log(id);
    fetch(`http://localhost:8081/deleteRobot/${id}`, {
        method: 'DELETE',
        headers: { 'content-type': 'application/json' },
    })
        .then(response => response.json())
        .then(deleteThisRobot => { deleteRobotById(deleteThisRobot) });
    alert("Robot deleted successfully! Click 'All Robots' to view updated list");
}

//update robot
function updateRobot() {
    let id = document.getElementById("updateRobotById").value;
    console.log(id);
    fetch(`http://localhost:8081/updateRobot/${id}`, {
        method: 'PUT',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify(
            {
                "name": "ROBOT BELLA 2.0",
                "price": 98.90,
                "description": "New description of robot Bella 2.0",
                "imageUrl": "https://robohash.org/Bella2"
            }
        )
    })
        .then(response => response.json())
        .then(updateThisRobot => { updateRobotById(updateThisRobot) });
    alert("Robot updated successfully! Click 'All Robots' to view updated list");
}

//show updated robot list
function showAllRobots() {
    fetch("http://localhost:8081/listRobots")
        .then(response => response.json())
        .then(robots => loadRobotList(robots));
}