// Author: Bella Singh
// ISU Netid : bellas23@iastate.edu
// Date :  April 15th, 2024

fetch("http://localhost:8081/listRobots")
    .then(response => response.json())
    .then(myListRobots => {
        loadListRobot(myListRobots);
    });

function loadListRobot(myListRobots) {
    var CardRobots = document.getElementById("col");

    // Read every robot from the array
    for (var i = 0; i < myListRobots.length; i++) {

        let id = myListRobots[i].id;
        let name = myListRobots[i].name;
        let price = myListRobots[i].price;
        let description = myListRobots[i].description;
        let url = myListRobots[i].imageUrl;

        // create a new HTML div division
        let AddCardRobots = document.createElement("div");
        // add class = “col” to new division for Bootstrap
        AddCardRobots.classList.add("col");
        // create Bootstrap card
        AddCardRobots.innerHTML = `
                <div class="card shadow-sm">
                    <img src=${url} class="card-img-top" alt="..."
                    <div class="card-body">
                        <p class="card-text">${id}, <strong>${name}</strong>, $${price}</p>
                        <p>${description}</p>
                    </div>
                </div>
            `;
        // append new division
        CardRobots.appendChild(AddCardRobots);
    } // end of for
} // end of function


function showOneRobot() {
    let id = document.getElementById("robotId").value;

    fetch(`http://localhost:8081/${id}`)
        .then(response => response.json())
        .then(myFavoriteRobot => { loadOneRobot(myFavoriteRobot) });

    function loadOneRobot(myFavoriteRobot) {
        var CardRobot = document.getElementById("col2");

        let id = myFavoriteRobot.id;
        let name = myFavoriteRobot.name;
        let price = myFavoriteRobot.price;
        let description = myFavoriteRobot.description;
        let url = myFavoriteRobot.imageUrl;

        let AddCardRobot = document.createElement("div");
        AddCardRobot.classList.add("col2");
        AddCardRobot.innerHTML = `
        <div class = "card shadow-sm">
            <img src = ${url} class ="card-img-top" alt="...></img>
                <div class = "card-body">
                    <p class "card-text">${id} <strong>${name}</strong> $${price}</p>
                    <p>${description}</p>
                </div>
        </div>
        `;
        CardRobot.appendChild(AddCardRobot);
    }
}