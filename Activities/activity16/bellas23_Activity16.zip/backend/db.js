// Author: Bella Singh
// ISU Netid : bellas23@iastate.edu
// Date :  April 24, 2024

const mysql = require('mysql2/promise')

const db = mysql.createPool({
    host: "127.0.0.1",
    user: "bellas23",
    password: "Packswim0323"
    ,
    database: "secoms319"
})

module.exports = db;