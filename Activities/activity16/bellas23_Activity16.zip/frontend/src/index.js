// Author: Bella Singh
// ISU Netid : bellas23@iastate.edu
// Date :  April 24, 2024

import React from 'react';
import ReactDOM from 'react-dom/client';
// import "bootstrap/dist/css/bootstrap.css";
import App from './appfrontend.js';

const root = ReactDOM.createRoot(document.getElementById('root'));

root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);